/* Sylhet division college list
Make List Using Map & JSON Array
*/   



let collegeList=[

    {name:'Abdul Gafur Islami Adarsha High School And College', group: 'Humanities'},

    {name:'Amberkhana Girls School And College',group:'Business Studies'},

    {name:'Badaghat Model School And Colleg',group:'Humanities'},

    {name:'Blue Bird High School And College',group:'Science'},

    {name:'Border Guard Public School And College',group:'Business Studies'},

    {name:'Britannica Womens College',group:'Business Studies'},

    {name:'Blue Bird High School And College',group:'Humanities'},

    {name:'British Bangladesh International School & College',group:'Science'},

    {name:'Central Womens College',group:'Humanities'},

    {name:'Chartered College',group:'Business Studies'},

    {name:'Classic College',group:'Business Studies'},

    {name:'Eden Garden College',group:'Humanities'},

    {name:'Govt. Agragami Girls High School And College ',group:'Humanities'},

    {name:'Greenhill State College',group:'Business Studies'},

    {name:'Jalalabad Cantonment Public School And College',group:'Science'},

    {name:'Jalalabad College',group:'Humanities'},

    {name:'Madan Mohan College',group:'Business Studies'},

    {name:'Mainuddin Adarsha Girls College',group:'Science'},

    {name:'Metrocity Womens College',group:'Science'},
    
    {name:'Metrocity Womens College',group:'Science'},

    {name:'Pachim Sadar High School And College',group:'Humanities'},

    {name:'Saarc International College Bangladesh ',group:'Science'},

    {name:'Safiruddin High School And College',group:'Science'},

    {name:'Saheber Bazar High School And College',group:'Science'},

    {name:'Scholarshome',group:'Science'},

    {name:'Scholarshome Girls College',group:'Science'},

    {name:'Scholarshome Majortila College',group:'Humanities'},

    {name:'Shaha Khurram College',group:'Humanities'},

    {name:'Shahjalal City College',group:'Science'},

    {name:'Shahjalal Jamia Islamia School And College',group:'Science'},

    {name:'Shaparan Govt. College ',group:'Science'},

    {name:'Shimantik College',group:'Science'},

    {name:'Shimantik College',group:'Science'},

    {name:'State College',group:'Science'},

    {name:'Sylhet Cambrian College',group:'Humanities'},

    {name:'Sylhet Central College',group:'Science'},

    {name:'Sylhet Govt. College',group:'Humanities'},

    {name:'Sylhet Govt. Womens College',group:'Science'},

    {name:'Sylhet Ideal College',group:'Science'},

    {name:'Sylhet Model School And College',group:'Science'},

    {name:'Sylhet M. C. College',group:'Science'},

    {name:'Sylhet Model School And College',group:'Science'},

    {name:'Sylhet Science College ',group:'Humanities'},

    {name:'Sylhet United Model College ',group:'Business Studies'},

    {name:'The Royal M. C. Academy',group:'Humanities'},

    {name:'The Sylhet Khajanchibari International School And College ',group:'Business Studies'},

    {name:'Universal College',group:'Science'},

    {name:'Westpoint College',group:'Science'},

    {name:'Westpoint College',group:'Science'},
    
    {name:'Barohal College',group:'Science'},

    {name:'Golam Mostofa Chow. Academy',group:'Business Studies'},

    {name:'Golam Mostofa Chow. Academy',group:'Business Studies'},

    {name:'Guru Saday High School And College',group:'Business Studies'},

    {name:'Hafsa Majumder Mohila College',group:'Business Studies'},

    {name:'Isamati College',group:'Science'},

    {name:'Lutfur Rahman High School And College',group:'Business Studies'},

    {name:'hah Bag High School And College',group:'Science'},
    
    {name:'Zakiganj Govt. College',group:'Science'},

    {name:'Shamsunnessa Women S College',group:'Science'},

    {name:'Starlight College',group:'Science'},

    {name:'Starlight College',group:'Science'},

    {name:'Renga Haziganj High School And College',group:'Humanities'},

    {name:'Noor Jahan Memorial Womens College',group:'Science'},

    {name:'Nabarun High School And College',group:'Humanities'},

    {name:'Latifa- Shafi Choudhury Women S College',group:'Science'},

    {name:'Lala Bazar Dipakkhik High School And College',group:'Humanities'},

    {name:'Jalalpur College',group:'Science'},

    {name:'Jalalpur College',group:'Science'},

    {name:'Israb Ali High School And College',group:'Science'},

    {name:'Dakshin Surma College ',group:'Business Studies'},

    {name:'Zhingabari High School And College',group:'Science'},

    {name:'Shikder Foundation College',group:'Science'},

    {name:'Malik-Nahar Memorial Academy',group:'Science'},

    {name:'Kanaighat Mohila College ',group:'Business Studies'},

    {name:'Kanaighat College',group:'Science'},

    {name:'Gasbari Ideal College',group:'Science'},

    {name:'Durgapur High School And College',group:'Science'},

    {name:'Charipara High School And College',group:'Business Studies'},

    {name:'Romjan Rupjan Bager Khal Academy',group:'Business Studies'},

    {name:'Rangpani Captain Rashid High School & College',group:'Science'},

    {name:'Jointia College ',group:'Science'},

    {name:'ointapur Tayub Ali College',group:'Science'},

    {name:'Imran Ahmad Womens College',group:'Science'},

    {name:'Hajrat Shaha Jalal (R) College',group:'Science'},

    {name:'Towakul College',group:'Humanities'},

    {name:'Salutikor College',group:'Business Studies'},

    {name:'Goainghat College',group:'Humanities'},

    {name:'Dashgaon Noagaon High School And College',group:'Humanities'},

    {name:'Amir MIah High School and College',group:'Science'},

    {name:'Ranakeli Girls High School And College',group:'Humanities'},

    {name:'Rana Ping Adarsha High School And College',group:'Humanities'},

    {name:'Rana Ping Adarsha High School And College',group:'Science'},

    {name:'Kushiara College',group:'Science'},

    {name:'Hazi Abdul Ahad High School And College',group:'Science'},

    {name:'Kushiara College ',group:'Science'},

    {name:'Kushiara College ',group:'Business Studies'},

    {name:'Fulshaind Bl. High School And College',group:'Science'},

    {name:'Dr. Soyed Moqbul Hossain High School And College',group:'Humanities'},

    {name:'Dhakadakshin Multilateral High School And College',group:'Science'},

    {name:'Kulaura Degree College ',group:'Humanities'},

    {name:'Gazbhag Ahammad Ali High School And College',group:'Science'},
    

]

export {collegeList};