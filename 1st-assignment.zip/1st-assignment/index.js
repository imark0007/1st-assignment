import {collegeList} from "./collegeList.js";

collegeList.map((item,i)=>{
    let Details=`My College Name is ${item.name}`
    console.log(Details);
})
